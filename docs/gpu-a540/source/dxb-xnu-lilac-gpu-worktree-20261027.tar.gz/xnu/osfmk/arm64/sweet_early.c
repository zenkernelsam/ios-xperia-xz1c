/*
 * Redmi Note 10 Pro bootstrap console. No allocation, locks, ADT parsing or
 * per-CPU state: panic() can reach this before a current thread exists.
 * start.s maps the splash framebuffer VA=PA as Normal Non-Cacheable memory.
 * arm_vm_init installs a reserved kernel VA alias before removing TTBR0;
 * retain this console until the normal framebuffer serial console is ready.
 */
#include <arm64/sweet_early.h>

#if defined(SWEET)
#include <stdint.h>
#include <kern/misc_protos.h>
#include <arm64/proc_reg.h>

/* lilac panel consumes RGB888 (qcom,mdss-dsi-bpp=24): each pixel is
 * 3 bytes, 720 px = 2160 B per line. Write bytes, keep -mstrict-align. */
static volatile uint8_t *early_fb = (volatile uint8_t *)(uintptr_t)0x9d400000;
#define EARLY_FB early_fb
/* IMEM restart_reason: mapped VA=PA by start.s, remapped beside the
 * framebuffer alias by arm_vm_init. ABL echoes it into the next Android
 * cmdline as warmboot=0x........  0x77664Dxx = 'M' + stage,
 * 0x776650xx = 'P' panic.  BUT ABL rewrites the official field on
 * `fastboot reboot`, so every mark is mirrored into early_durable --
 * reserved debug_region DDR tail at phys 0xffbff000 (inside the
 * 0xfe000000 32 MiB block) that nothing else touches; read it from
 * Android via fmem. */
static volatile uint32_t *early_rr = (volatile uint32_t *)(uintptr_t)0x146bf65c;
#define EARLY_RR early_rr
static volatile uint32_t *early_imem =
	(volatile uint32_t *)(uintptr_t)0x146bf000;
static volatile uint32_t *early_durable =
	(volatile uint32_t *)(uintptr_t)0xffbff000;
#define EARLY_DURABLE early_durable
/* ramoops record prz @ slot 7 of the 0xffc00000 zone: ABL ignores it and
 * Android pstore surfaces it as record-ramoops-* with no fmem needed. */
static volatile uint32_t *early_prz =
	(volatile uint32_t *)(uintptr_t)0xffc07000;
static unsigned int early_mark_seq;

#define PERSISTENT_RAM_SIG 0x43474244u

/* PM8998 PON spare byte 0x88e through the SPMI pmic-arbiter v2 write
 * channel (CAF spmi-pmic-arb.c): apid 4 => 0x8400000 + 0x8000*4.
 * Per-channel regs: CMD=0x00 STATUS=0x08 WDATA0=0x10; PON 0x8xx uses
 * EXT_WRITE (opc 0, addr<11:4). Survives warm + crash resets; Android
 * reads it via /sys/kernel/debug/regmap/spmi0-00. PON byte encoding:
 *   0x00-0x7f = stage marks (low byte of 0x77664Dxx / 0x7766D0xx),
 *   0x80-0x9f = panic mark (0x80 | last_stage), distinct from stage. */
static volatile uint32_t *early_pon =
	(volatile uint32_t *)(uintptr_t)0x8420000;
static void
early_pon_write_reg(unsigned int reg, uint32_t v)
{
	early_pon[4] = v & 0xff;                       /* CH_WDATA0 */
	early_pon[0] = (0u << 27) | ((reg & 0xffu) << 4); /* CH_CMD EXT_WRITE */
	for (int i = 0; i < 100000; i++)
		if (early_pon[2] & 1u)                     /* CH_STATUS DONE */
			return;
}

static void
early_pon_write(uint32_t v)
{
	early_pon_write_reg(0x8e, v);
}

/* Route the next reset to fastboot (SOFT_RB_SPARE=0x06, the same byte the
 * shim writes with RET=1) and reset via PSCI SYSTEM_RESET. This replaces the
 * physical power press for any XNU run that is still executing. */
void
sweet_pon_arm_fastboot(void)
{
	early_pon_write_reg(0x8f, 0x06);
	__asm__ volatile("dsb sy" ::: "memory");
}

volatile uint32_t *sweet_wdt_rst;

void
sweet_ddr_mark(uint64_t tag, uint64_t v)
{
	extern volatile char sweet_panic_cell[];
	volatile uint64_t *c = (volatile uint64_t *)(void *)sweet_panic_cell;
	uintptr_t line = ((uintptr_t)c + 0x1A0) & ~(uintptr_t)63;

	c[0x34] = tag;
	c[0x35] = v;
	__asm__ volatile("dc civac, %0" :: "r"(line) : "memory");
	__asm__ volatile("dsb sy" ::: "memory");
}

void
sweet_reset_to_fastboot(void)
{
	sweet_ddr_mark(0x54535241ULL, 0);	/* 'ARST' */
	sweet_pon_arm_fastboot();
	__asm__ volatile("mov x0, %0" :: "r"(0x84000009ULL) : "x0", "memory");
	__asm__ volatile("smc #0" ::: "memory");
	for (;;) {
		__asm__ volatile("wfe");
	}
}

static void
early_stage_write(unsigned int v)
{
	early_pon_write(v);
	*EARLY_RR = v;
	*EARLY_DURABLE = v;
	early_durable[1] = ++early_mark_seq;
	early_imem[0x80] = v;	/* 0x146bf200 */
	early_imem[0xc0] = v;	/* 0x146bf300 */
	early_imem[0x100] = v;	/* 0x146bf400 */
	early_imem[0x140] = v;	/* 0x146bf500 */
	early_prz[0] = PERSISTENT_RAM_SIG;
	early_prz[1] = 0;
	early_prz[2] = 16;
	early_prz[3] = v;
	early_prz[4] = early_mark_seq;
	early_prz[5] = 0x6c4c5252u;
	early_prz[6] = ~v;
	__asm__ volatile("dsb sy" ::: "memory");
}
#define EARLY_WIDTH 720u
#define EARLY_HEIGHT 1280u
#define EARLY_STRIDE (2160u / 3)
#define EARLY_SCALE 2u
#define EARLY_CELL_W (8u * EARLY_SCALE)
#define EARLY_CELL_H (16u * EARLY_SCALE)
#define EARLY_ROWS ((EARLY_HEIGHT - 32u) / EARLY_CELL_H)
#define EARLY_COLS (EARLY_WIDTH / EARLY_CELL_W)

extern unsigned char iso_font[256 * 16];

/* Initialized data must remain writable until disable, including panics. */
static unsigned int early_row, early_col;
static unsigned int early_started, early_disabled, early_panicking;
static unsigned int early_last_stage;

static void
sweet_early_clear_row(void)
{
	for (unsigned int y = 0; y < EARLY_CELL_H; y++) {
		volatile uint8_t *line = EARLY_FB + (early_row * EARLY_CELL_H + y) * EARLY_STRIDE * 3;
		for (unsigned int x = 0; x < EARLY_WIDTH * 3; x++) {
			line[x] = 0x00u;
		}
	}
}

/* Rolling log of every exec name; flushed to DDR so the next fastboot can
 * read it (headless bring-up observability). PA = symbol VA - virt_base +
 * phys_base, i.e. 0xA0000000 + (VA & 0x1fffffff). */
#define SWEET_EXEC_RING_SIZE 1024
char sweet_exec_ring[SWEET_EXEC_RING_SIZE];
static unsigned int sweet_exec_ring_len;
static uint32_t sweet_exec_seq;

void
sweet_note_exec(const char *name)
{
	char line[48];
	unsigned int n = 0, i;
	uint32_t v = ++sweet_exec_seq;
	char d[10];
	int t = 0;

	do {
		d[t++] = (char)('0' + (v % 10));
		v /= 10;
	} while (v);
	while (t > 0) {
		line[n++] = d[--t];
	}
	line[n++] = ' ';
	for (i = 0; name != NULL && name[i] != 0 && i < 23; i++) {
		line[n++] = name[i];
	}
	line[n++] = '\n';
	if (sweet_exec_ring_len + n > SWEET_EXEC_RING_SIZE) {
		unsigned int drop = sweet_exec_ring_len + n - SWEET_EXEC_RING_SIZE;
		if (drop > sweet_exec_ring_len) {
			drop = sweet_exec_ring_len;
		}
		__builtin_memmove(sweet_exec_ring, sweet_exec_ring + drop,
		    sweet_exec_ring_len - drop);
		sweet_exec_ring_len -= drop;
	}
	for (i = 0; i < n; i++) {
		sweet_exec_ring[sweet_exec_ring_len++] = line[i];
	}
	for (uintptr_t a = (uintptr_t)sweet_exec_ring & ~63UL;
	    a < (uintptr_t)sweet_exec_ring + SWEET_EXEC_RING_SIZE; a += 64) {
		__asm__ volatile("dc civac, %0" :: "r"(a) : "memory");
	}
	__asm__ volatile("dsb sy" ::: "memory");
}

void
sweet_early_putc(char c)
{
	if (early_disabled) {
		return;
	}
	if (!early_started) {
		early_started = 1;
		sweet_early_clear_row();
	}
	if (c == '\r') {
		early_col = 0;
		return;
	}
	if (c == '\n' || early_col == EARLY_COLS) {
		early_col = 0;
		early_row = (early_row + 1) % EARLY_ROWS;
		sweet_early_clear_row();
		if (c == '\n') {
			return;
		}
	}
	const unsigned char *glyph = iso_font + (unsigned char)c * 16;
	for (unsigned int gy = 0; gy < 16; gy++) {
		for (unsigned int sy = 0; sy < EARLY_SCALE; sy++) {
			volatile uint8_t *line = EARLY_FB +
			    (early_row * EARLY_CELL_H + gy * EARLY_SCALE + sy) * EARLY_STRIDE * 3 +
			    early_col * EARLY_CELL_W * 3;
			for (unsigned int gx = 0; gx < 8; gx++) {
				uint8_t pixel = (glyph[gy] & (1u << gx)) ? 0xffu : 0x00u;
				for (unsigned int sx = 0; sx < EARLY_SCALE; sx++) {
					volatile uint8_t *px = line + (gx * EARLY_SCALE + sx) * 3;
					px[0] = pixel; px[1] = pixel; px[2] = pixel;
				}
			}
		}
	}
	early_col++;
}

/* Panic text sink in the splash reservation (identity-mapped Normal-NC by
 * start.s): the shim reads it on the next boot when the panel is dark. */
static volatile char *early_ddr_buf = (volatile char *)(uintptr_t)0x9F700000;
static unsigned int early_ddr_pos;

static void
sweet_early_ddr_putc(char c)
{
	if (early_ddr_pos < 2000) {
		early_ddr_buf[early_ddr_pos++] = c;
		early_ddr_buf[early_ddr_pos] = 0;
	}
	__asm__ volatile("dsb sy" ::: "memory");
}

static void
sweet_early_string(const char *s)
{
	while (*s) {
		sweet_early_putc(*s++);
	}
}

void
sweet_early_mark(unsigned int stage, const char *label)
{
	if (stage > 60) {
		return;
	}
	early_last_stage = stage;
	early_stage_write(0x77664D00u | stage);
	__asm__ volatile("dsb sy" ::: "memory");
	if (early_disabled) {
		return;
	}
	uint8_t shade = (uint8_t)(0x80u | ((stage & 7u) << 5));
	for (unsigned int y = EARLY_HEIGHT - 32; y < EARLY_HEIGHT; y++) {
		for (unsigned int x = stage * 48; x < (stage + 1) * 48; x++) {
			volatile uint8_t *px = EARLY_FB + (y * EARLY_STRIDE + x) * 3;
			px[0] = shade; px[1] = 0xffu; px[2] = 0x00u;
		}
	}
	__asm__ volatile("dsb sy" ::: "memory");
	sweet_early_string("SWEET EARLY ");
	if (stage >= 10) {
		sweet_early_putc((char)('0' + stage / 10));
	}
	sweet_early_putc((char)('0' + stage % 10));
	sweet_early_string(": ");
	sweet_early_string(label);
	sweet_early_putc('\n');
}

void
sweet_early_panic(const char *fmt, va_list *args)
{
	if (early_disabled || early_panicking) {
		return;
	}
	early_panicking = 1;
	early_stage_write(0x77665000u | (early_last_stage & 0xff));
	__asm__ volatile("dsb sy" ::: "memory");
	/* Panic gets a distinct PON byte (0x80|stage) so a postmortem
	 * read can tell "died mid-stage-N" from "panicked at stage-N". */
	early_pon_write(0x80u | (early_last_stage & 0x3f));
	__asm__ volatile("dsb sy" ::: "memory");
	sweet_early_string("\nSWEET EARLY PANIC: ");
	va_list copy;
	va_copy(copy, *args);
	_doprnt(fmt, &copy, sweet_early_putc, 16);
	va_end(copy);
	/* Mirror the formatted text into the splash DDR cell for the shim. */
	early_ddr_pos = 0;
	early_ddr_buf[0] = 'P'; early_ddr_buf[1] = 'A';
	early_ddr_buf[2] = 'N'; early_ddr_buf[3] = 'G';
	early_ddr_pos = 4;
	va_copy(copy, *args);
	_doprnt(fmt, &copy, sweet_early_ddr_putc, 16);
	va_end(copy);
	sweet_early_putc('\n');
	__asm__ volatile("dsb sy" ::: "memory");
	/* Keep the panel alive with the panic text on it: spin instead of
	 * resetting; the loader-armed APSS WDT bites within ~60 s and the
	 * next shim run harvests the DDR mirror. */
	for (;;) {
		__asm__ volatile("wfe");
	}
}

/* kernel_bootstrap phase hash: PON byte 0x40-0x7f identifies the
 * last kernel_bootstrap_log() message (see research/phase_hash.py). */
static volatile unsigned int early_step_id;

void
sweet_early_step(unsigned int id)
{
	early_step_id = id;
	early_pon_write(id & 0x7fu);
}

/* panic(): 0x80|(last step & 0x3f) distinguishes 'panicked at step N'
 * from 'still hung at step N' (which reads 64+N). */
void
sweet_early_step_late(unsigned int id)
{
	early_step_id = id;
	early_pon_write(0x40u | ((id - 64u) & 0x3fu));
	{
		/* Fastboot-readable progress record: PON needs Android, DDR does not. */
		extern volatile char sweet_panic_cell[];
		volatile uint64_t *c = (volatile uint64_t *)(void *)sweet_panic_cell;
		uintptr_t line = ((uintptr_t)c + 0x180) & ~(uintptr_t)63;
		c[0x30] = 0x50455453ULL;	/* 'STEP' */
		c[0x31] = (uint64_t)id;
		__asm__ volatile("dc civac, %0" :: "r"(line) : "memory");
		__asm__ volatile("dsb sy" ::: "memory");
	}
}

void
sweet_early_ddr_rooted(void)
{
	extern volatile char sweet_panic_cell[];
	volatile uint64_t *c = (volatile uint64_t *)(void *)sweet_panic_cell;

	uintptr_t line = ((uintptr_t)c + 0x180) & ~(uintptr_t)63;
	c[0x32] = 0x544f4f52ULL;	/* 'ROOT' */
	c[0x33] = 158;
	__asm__ volatile("dc civac, %0" :: "r"(line) : "memory");
	__asm__ volatile("dsb sy" ::: "memory");
}

void
sweet_early_pon_raw(unsigned int v)
{
	early_pon_write(v & 0xffu);
}

void
sweet_early_panic_beacon(void)
{
	early_pon_write(0x80u | (early_step_id & 0x3fu));
}

void
sweet_early_phase(unsigned int id)
{
	early_pon_write(0x40u | (id & 0x3fu));
}

void
sweet_early_hex(const char *tag, uint64_t v)
{
	static const char hx[] = "0123456789ABCDEF";
	char b[17];
	for (int i = 0; i < 16; i++)
		b[i] = hx[(v >> (60 - 4 * i)) & 0xf];
	b[16] = 0;
	sweet_early_string(tag);
	sweet_early_string(b);
	sweet_early_putc(10);
}

void
sweet_early_relocate(uint64_t base)
{
	sweet_early_mark(8, "leaving bootstrap TTBR0");
#if defined(ARM64_BOARD_CONFIG_SAGIT)
	/* 4 KiB alias slots: FB 0..17 (2 MiB each), IMEM 18,
	 * durable+pstore 19, SPMI 20. Slot 0 maps PA 0x9d400000 at base. */
	early_fb = (volatile uint8_t *)(uintptr_t)base;
	early_rr = (volatile uint32_t *)(uintptr_t)(base + 18 * ARM_TT_L2_SIZE + 0xbf65c);
	early_imem = (volatile uint32_t *)(uintptr_t)(base + 18 * ARM_TT_L2_SIZE + 0xbf000);
	early_durable = (volatile uint32_t *)(uintptr_t)(base + 19 * ARM_TT_L2_SIZE + 0x1ff000);
	early_prz = (volatile uint32_t *)(uintptr_t)(base + 19 * ARM_TT_L2_SIZE + 0x207000);
	/* slot[20] maps phys 0x08400000; SPMI apid-4 write ch at +0x20000 */
	early_pon = (volatile uint32_t *)(uintptr_t)(base + 20 * ARM_TT_L2_SIZE + 0x20000);
#else
	sweet_early_mark(8, "leaving bootstrap TTBR0");
	early_fb = (volatile uint32_t *)(uintptr_t)(base + 0x1400000);
	early_rr = (volatile uint32_t *)(uintptr_t)(base + ARM_TT_L2_SIZE + 0x6bf65c);
	early_imem = (volatile uint32_t *)(uintptr_t)(base + ARM_TT_L2_SIZE + 0x6bf000);
	early_durable = (volatile uint32_t *)(uintptr_t)(base + 2 * ARM_TT_L2_SIZE + 0x1bff000);
	early_prz = (volatile uint32_t *)(uintptr_t)(base + 2 * ARM_TT_L2_SIZE + 0x1c07000);
	/* slot[3] = phys 0x8000000; SPMI apid-4 write ch at +0x420000 */
	early_pon = (volatile uint32_t *)(uintptr_t)(base + 3 * ARM_TT_L2_SIZE + 0x420000);
#endif
	__asm__ volatile("dsb sy" ::: "memory");
	sweet_early_mark(9, "kernel framebuffer VA live");
}

void
sweet_early_disable(void)
{
	early_disabled = 1;
	__asm__ volatile("dsb sy" ::: "memory");
}
#endif /* SWEET */
